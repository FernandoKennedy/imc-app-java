package br.com.imc;

public class Entradas {
	// variaveis
	public String nome;
	public int idade;
	public double peso;
	public double altura;		
	
}
