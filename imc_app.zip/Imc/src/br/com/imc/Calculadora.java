package br.com.imc;

import java.util.Scanner;

public class Calculadora {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Variaveis
		String nome;
		int idade;
		double peso;
		double altura;
				
		// instancia os objetos
		Entradas usuario = new Entradas();
		Scanner leia = new Scanner(System.in);
				
		// Dados de entrada
		System.out.println("Informe seu nome:");
		usuario.nome = leia.nextLine();
		System.out.println("Informe sua idade:");
		usuario.idade = leia.nextInt();
		System.out.println("Informe seu peso:");
		usuario.peso = leia.nextDouble();
		System.out.println("Informe sua altua:");
		usuario.altura = leia.nextDouble();
		
		double formula = (usuario.peso / (usuario.altura * usuario.altura));
		System.out.println("Seu IMC � de: " + formula);

		
				
	}

}
